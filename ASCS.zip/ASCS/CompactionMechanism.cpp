using namespace std;
#include <vector>;
#include "Rule_001.h";
#include "PopulationPool.h";
#include "Rule001_Oper.h";
#include "MatchList.h";
#include "BooleanEnvironment.h";
#include "CompactionMechanism.h";
#include<string>;
#include <iostream>;

//initialize the compaction mechanism need a config document
CompactionMechanism::CompactionMechanism(Config &cof)
{
	CompactionMechanism::cof = cof;
}


//generate a Prediction_List
vector<int> CompactionMechanism::Prediction_List(int &numActions)
{
	vector<int> P_List{};
	for (int i = 0; i < numActions; ++i)
	{
		P_List.push_back(0);
	}
	return P_List;
}

//reset the value list in the prediction list
void CompactionMechanism::EmptyPrediction_List(vector<int> &P_List)
{
	for (int i = 0; i < P_List.size(); ++i)
	{
		P_List[i] = 0;
	}
}

//calculate the prediction result
bool CompactionMechanism::Prediction_Result(vector<int> &P_List, int &realAction)
{
	int max = 0;
	int action = 0;
	for (int i = 0; i < P_List.size(); ++i)
	{
		if (P_List[i] > max)
		{
			max = P_List[i];
			action = i;
		}
	}

	//unmatched
	if (max == 0)
	{
		return false;
	}

	//asscert whether the action is correct
	if (action == realAction)
	{
		return true;
	}
	else
	{
		return false;
	}

}


//check whether this rule is inconsistent
bool CompactionMechanism::IsInconsistent(bool &PN_state, int &P_Action, int &R_Action)
{
	//false: informed mutation; true: absumption set
	bool result = false;

	//judge whether the environment action is equilivant to the population's action
	bool consistent = false;
	if (R_Action == P_Action)
	{
		consistent = true;
	}

	//rule is inconsistent thus should be classified into absumption set otherwise the rule should be send into 
	//informed operator set
	if (PN_state ^ consistent)
	{
		result = true;
	}
	return result;
}


//detect the inconsistent rules for remove meanwhile update the training parameters and prediction list
std::vector<std::vector<int>> CompactionMechanism::Prediction_update(std::vector<string> &state, std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &I_Action, vector<int> &P_List)
{
	//record the id of rules that match the received instance
	std::vector<std::vector<int>> Matchs;
	for (int p = 0; p < Populations.size(); ++p)
	{
		//Cluster ID
		for (int c = 0; c < Populations[p].Clusters.size(); ++c)
		{
			//Rule ID
			for (int r = 0; r < Populations[p].Clusters[c].Rules.size(); ++r)
			{
				if (R_O.IsConditionMatch(state, Populations[p].Clusters[c].Rules[r].condition))
				{
					//update the score in the P_List
					if (Populations[p].PN_state==true)
					{
						P_List[Populations[p].Action] += Populations[p].Clusters[c].Rules[r].P_p;
					}
					else
					{
						P_List[Populations[p].Action] -= Populations[p].Clusters[c].Rules[r].N_p;

					}

					//check whether the rule is inconsisitent
					if (CompactionMechanism::IsInconsistent(Populations[p].PN_state, Populations[p].Action,I_Action)==true)
					{
						//store the ID
						std::vector<int> ID{};
						ID.push_back(p);
						ID.push_back(c);
						ID.push_back(r);
						Matchs.push_back(ID);
						//increase the number of removed rules in the compaction inconsistent remover
						Populations[p].Clusters[c].C_Aubsumed_num.back()++;
					}

					//update the training parameters
					if (Populations[p].Action == I_Action)
					{
						Populations[p].Clusters[c].Rules[r].P_p++;
					}
					else
					{
						Populations[p].Clusters[c].Rules[r].N_p++;
					}
				}
			}
		}
	}
	//return the matched rules
	return Matchs;
}

//remove the identified problematic rules
void CompactionMechanism::RuleRemover(std::vector<ASCS_Population> &Populations, std::vector<std::vector<int>> &R_List)
{
	//initial population id and cluster id
	int p = R_List[0][0];
	int c = R_List[0][1];
	int count = 0;

	for (int i = 0; i < R_List.size(); ++i)
	{
		//remove the marked rule
		//Must brackets (Ab_List[i][2]-count), otherwise, raise up errors
		Populations[p].Clusters[c].Rules.erase(Populations[p].Clusters[c].Rules.begin() + (R_List[i][2] - count));

		//population's number rules minus one
		Populations[p].num_Rules--;


		//before the last one
		if (i < R_List.size() - 1)
		{
			//set the count
			if (p == R_List[i + 1][0] && c == R_List[i + 1][1])
			{
				count++;
			}
			else
			{
				count = 0;
				p = R_List[i + 1][0];
				c = R_List[i + 1][1];
			}
		}
	}

   //free memory
	R_List.clear();
	R_List.shrink_to_fit();
}

//execute the inconsistent remover
void CompactionMechanism::inconsistent_remover(std::vector<ASCS_Population> &populations, BooleanEnvironment &env, Rule001_Oper &R_O)
{
	//initial a prediction list
	vector<int> P_List = CompactionMechanism::Prediction_List(env.action_number);
	int correct = 0;

	for (int i = 0; i < CompactionMechanism::cof.C_number; ++i)
	{
		//randomly generate a sample of the target problem
		std::vector<int> state_i = env.Create_set_Condition();
		std::vector<string> state_s = env.Convert_state_char(state_i);
		int P_action = env.execute_Problem(state_i);

		//get the list for remove and update the parameters in the population
		std::vector< std::vector<int>> R_List = CompactionMechanism::Prediction_update(state_s, populations, R_O, P_action, P_List);


		//remove the incorrect rules;
		if (R_List.size() > 0)
		{
			CompactionMechanism::RuleRemover(populations, R_List);
		}

		if (CompactionMechanism::Prediction_Result(P_List, P_action))
		{
			correct++;
		}

		//empty the P_List
		CompactionMechanism::EmptyPrediction_List(P_List);

		//free memory
		state_i.clear();
		state_i.shrink_to_fit();
		state_s.clear();
		state_s.shrink_to_fit();

	}

	//calculate accuracy and store
	int accuracy = (100 * correct) / CompactionMechanism::cof.C_number;
	std::cout << "accuracy before: " << accuracy << "%"<<std::endl;
	CompactionMechanism::P_Rlist_Before.push_back(accuracy);
}

//Run the compaction mechanism
void CompactionMechanism::run(std::vector<ASCS_Population> &populations, BooleanEnvironment &env, Rule001_Oper &R_O)
{
	//remove the inconsistant rules
	CompactionMechanism::inconsistent_remover(populations, env, R_O);

	//exeID 0: Error check by rules in the same generalization or lower
	//exeID 1: Error check by rules in a higher generalization level
	//compare a rules with other rules that in a lower or the same generalization level to get ride of the incorrect rules
	int exeID = 0;
	CompactionMechanism::Error_remover(populations, R_O,exeID);

	//remove the subsumable rules
	CompactionMechanism::Subsume(populations, R_O);

	//compare a rule with other rules that in a higher generalization level to remove specific incorrect rules
	exeID = 1;
	CompactionMechanism::Error_remover(populations, R_O, exeID);

	//update the remained rules' parameters
	CompactionMechanism::UpdateSubState(populations);

	//update the state of searchable searchspace
	CompactionMechanism::UpdateClustersVailable(populations);

	if (cof.Test_Control)
	{
		//test the population's performance
		CompactionMechanism::PredictionAccuracy(populations, env, R_O);
	}

}

//true: corect   false: incorrect
//asscert whether a rule is incorrect by compare with rules that in a lower or the same generalization level
bool CompactionMechanism::IsCorrect(std::vector<ASCS_Population> &Populations, int &p, int c, int &r, Rule001_Oper &R_O)
{
	for (int p1 = 0; p1 < Populations.size(); ++p1)
	{
		//initial the conflict value
		int conflit = 0;
		int believe = Populations[p].Clusters[c].Rules[r].N_p + Populations[p].Clusters[c].Rules[r].P_p;

		//different action same PNstate or different PNstate same action
		if (((Populations[p].Action != Populations[p1].Action) && (Populations[p].PN_state == Populations[p1].PN_state)) ||
			((Populations[p].Action == Populations[p1].Action) && (Populations[p].PN_state != Populations[p1].PN_state)))
		{
			for (int c1=c;c1>-1;--c1)
			{
				for (int r1 = 0; r1 < Populations[p1].Clusters[c1].Rules.size(); ++r1)
				{

					if( R_O.OverlapCondition(Populations[p].Clusters[c].Rules[r].condition, Populations[p1].Clusters[c1].Rules[r1].condition) )
					{
						conflit += Populations[p1].Clusters[c1].Rules[r1].N_p + Populations[p1].Clusters[c1].Rules[r1].P_p;
						//cout << conflit;
						if (conflit > believe)
						{
							return false;
						}
					}
				}
			}
		}
	}
	return true;
}


//asscert whether a rule is incorrect by compare with rules that in a higher generalization level
bool CompactionMechanism::IsCorrect_Specific(std::vector<ASCS_Population> &Populations, int &p, int c, int &r, Rule001_Oper &R_O)
{
	for (int p1 = 0; p1 < Populations.size(); ++p1)
	{
		//initial the conflict value
		int conflit = 0;
		int believe = Populations[p].Clusters[c].Rules[r].N_p + Populations[p].Clusters[c].Rules[r].P_p;

		//different action same PNstate or different PNstate same action
		if (((Populations[p].Action != Populations[p1].Action) && (Populations[p].PN_state == Populations[p1].PN_state)) ||
			((Populations[p].Action == Populations[p1].Action) && (Populations[p].PN_state != Populations[p1].PN_state)))
		{
			for (int c1 = Populations[p].Clusters.size()-1; c1>c; --c1)
			{
				for (int r1 = 0; r1 < Populations[p1].Clusters[c1].Rules.size(); ++r1)
				{

					if (R_O.OverlapCondition(Populations[p].Clusters[c].Rules[r].condition, Populations[p1].Clusters[c1].Rules[r1].condition))
					{
						conflit += Populations[p1].Clusters[c1].Rules[r1].N_p + Populations[p1].Clusters[c1].Rules[r1].P_p;
						//cout << conflit;
						if (conflit > believe)
						{
							return false;
						}
					}
				}
			}
		}
	}
	return true;
}

//identify the rules that are incorrect by comparing with other rules
std::vector<std::vector<int>> CompactionMechanism::Error_List(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &exeID)
{
	std::vector<std::vector<int>> R_List{};
	//population compare with each other
	for (int p = 0; p < Populations.size(); ++p)
	{
		
				//in the 
		for (int c = 0; c < Populations[p].Clusters.size(); ++c)
		{
			for (int r = 0; r < Populations[p].Clusters[c].Rules.size(); ++r)
			{
				//check whether this rule need to be checked
				if (Populations[p].Clusters[c].Rules[r].Sub_state == false)
				{
					bool Correct_state;
					//asscert whether the rule is error
					if (exeID == 0)
					{
						Correct_state = CompactionMechanism::IsCorrect(Populations, p, c, r, R_O);
					}
					else if(exeID == 1)
					{
						Correct_state = CompactionMechanism::IsCorrect_Specific(Populations, p, c, r, R_O);
					}

					if (!Correct_state)
					{
						//initial the ID of this rule
						std::vector<int> ID{};
						ID.push_back(p);
						ID.push_back(c);
						ID.push_back(r);
						R_List.push_back(ID);

						//increase the number of Error removed rules
						Populations[p].Clusters[c].C_Error_num.back()++;
					}
					

				}
			}

		}
					
	}

	return R_List;
}

//implement the error remover
void CompactionMechanism::Error_remover(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &exeID)
{
	std::vector<std::vector<int>> E_List = CompactionMechanism::Error_List(Populations, R_O, exeID);
	if (E_List.size() > 0)
	{
		CompactionMechanism::RuleRemover(Populations, E_List);
	}
}


//asscert whether a rule can be subsumed
bool CompactionMechanism::IsSubsumed(ASCS_Population &population, std::vector<string> &condition, Rule001_Oper &R_O, int &generalizationLevel)
{
	for (int c = population.Clusters.size() - 1; c >generalizationLevel; --c)
	{
		for (int r = 0; r < population.Clusters[c].Rules.size(); ++r)
		{
			if (R_O.SubsumeCondition(population.Clusters[c].Rules[r].condition, condition))
			{
				return true;
			}
		}
	}

	return false;
}


//identify rules that can be subsumed
std::vector<std::vector<int>> CompactionMechanism::Subsum_List(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O)
{
	//initialize the subsume list
	std::vector<std::vector<int>> S_List{};

	for (int p = 0; p < Populations.size(); ++p)
	{
		for (int c = 0; c < Populations[p].Clusters.size(); ++c)
		{
			for (int r = 0; r < Populations[p].Clusters[c].Rules.size(); ++r)
			{
				if (CompactionMechanism::IsSubsumed(Populations[p], Populations[p].Clusters[c].Rules[r].condition, R_O, c))
				{
					std::vector<int> ID{};
					ID.push_back(p);
					ID.push_back(c);
					ID.push_back(r);
					S_List.push_back(ID);

					//increase the number of subsumed rules
					Populations[p].Clusters[c].C_Subsumed_num.back()++;
				}
			}
		}
	}
	return S_List;
}


//execute the subsumption processing
void CompactionMechanism::Subsume(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O)
{
	std::vector<std::vector<int>> S_List = CompactionMechanism::Subsum_List(Populations, R_O);

	if (S_List.size() > 0)
	{
		CompactionMechanism::RuleRemover(Populations, S_List);
	}
}


//update the subsumption state for the remained rules 
void CompactionMechanism::UpdateSubState(std::vector<ASCS_Population> &Populations)
{
	for (int p = 0; p < Populations.size(); ++p)
	{
		for (int c = 0; c < Populations[p].Clusters.size(); ++c)
		{
			for (int r = 0; r < Populations[p].Clusters[c].Rules.size(); ++r)
			{
				Populations[p].Clusters[c].Rules[r].Sub_state = true;
			}
		}
	}
}


//produce the prediction accuracy after the compaction
void CompactionMechanism::PredictionAccuracy(std::vector<ASCS_Population> &populations, BooleanEnvironment &env, Rule001_Oper &R_O)
{
	//initial a prediction list
	vector<int> P_List = CompactionMechanism::Prediction_List(env.action_number);
	int correct = 0;


	for (int i = 0; i < CompactionMechanism::cof.Test_num; ++i)
	{
		//randomly generate a sample of the target problem
		std::vector<int> state_i = env.Create_set_Condition();
		std::vector<string> state_s = env.Convert_state_char(state_i);
		int P_action = env.execute_Problem(state_i);

		//get the list for remove and update the parameters in the population
		CompactionMechanism::UpdatepredictionList(state_s, populations, R_O, P_action, P_List);

		//check whether the prediction is correct
		if (CompactionMechanism::Prediction_Result(P_List, P_action))
		{
			correct++;
		}

		//empty the P_List
		CompactionMechanism::EmptyPrediction_List(P_List);


		//free memory
		state_i.clear();
		state_i.shrink_to_fit();
		state_s.clear();
		state_s.shrink_to_fit();
	}

	//calculate accuracy and store
	int accuracy = (100 * correct) / CompactionMechanism::cof.Test_num;
	std::cout << "accuracy after: " << accuracy << "%"<<std::endl;
	CompactionMechanism::P_Rlist_After.push_back(accuracy);

}

//update the score in the prediction list
void CompactionMechanism::UpdatepredictionList(std::vector<string> &state, std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &I_Action, vector<int> &P_List)
{
	for (int p = 0; p < Populations.size(); ++p)
	{
		//Cluster ID
		for (int c = 0; c < Populations[p].Clusters.size(); ++c)
		{
			//Rule ID
			for (int r = 0; r < Populations[p].Clusters[c].Rules.size(); ++r)
			{
				if (R_O.IsConditionMatch(state, Populations[p].Clusters[c].Rules[r].condition))
				{
					//update the score in the P_List
					if (Populations[p].PN_state == true)
					{
						P_List[Populations[p].Action] += Populations[p].Clusters[c].Rules[r].P_p;
					}
					else
					{
						P_List[Populations[p].Action] -= Populations[p].Clusters[c].Rules[r].N_p;

					}
				}
			}
		}
	}
}


//Control the searchspace
void CompactionMechanism::UpdateClustersVailable(std::vector<ASCS_Population> &populations)
{
	for (int p = 0; p < populations.size(); ++p)
	{
		//check the most specific cluster 0
		if (populations[p].Clusters[0].Rules.size() == 0)
		{
			populations[p].Clusters[0].Active = false;
		}
		else
		{
			populations[p].Clusters[0].Active = true;
		}

		for (int c = 1; c < populations[p].Clusters.size(); ++c)
		{
			if ((populations[p].Clusters[c].Rules.size() == 0) && (populations[p].Clusters[c - 1].Rules.size() == 0))
			{
				populations[p].Clusters[c].Active = false;
			}
			else
			{
				populations[p].Clusters[c].Active = true;
			}
		}
	}
}