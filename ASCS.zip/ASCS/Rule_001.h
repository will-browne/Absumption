#pragma once;
using namespace std;
#include <vector>;

class Rule_001
{
	public:


		Rule_001(std::vector<string> &condition, std::vector<int> attributelist);



		//an output action
		//int A;


		//positive experience
		int P_p;


		//negative experience
		int N_p;


		//state of whether can be used for subsumption
		bool Sub_state;



		//state that can be split into specified specified attributes and generalized attributes
		std::vector<string> condition{};
	

		//General list
		std::vector<int> Attributelist{};




};
