#pragma once;
using namespace std;
#include <vector>;
#include "ASCS_Cluster.h";
#include "ASCS_Population.h";
#include <map>;
#include "Rule_001.h";
#include "TrainingMechanism.h";
#include "MatchList.h";
#include <iostream>;
#include <ctime>;
#include <fstream>;
#include "BooleanEnvironment.h";
#include "Config.h";
#include "CompactionMechanism.h";

// This class store the algorithms for the population pool
class PopulationPool
{
public:

	PopulationPool();

	//update the cluster, this algorithm is invoked in each epoch except the first epoch
	void Reforged_Cluster(ASCS_Cluster &useCluster);

	std::vector<ASCS_Population> initial_Population_Pool(int &problem_length, vector<int> &action_list);

	//link the clusters
	void link_clusters(int &problem_length, ASCS_Population &population);

	//get the highest generalization
	void SetInitialHighest_Generalization(ASCS_Population &population);

	//get the highest valuable generalization level
	void SetHighest_Generalization(ASCS_Population &population);

	//Print the rules in each population
	void Print_Population(std::vector<ASCS_Population> &populations);


	//Print the general level List in each population
	void Print_GeneralLevel(Rule_001 &rule);


	//Print the match list
	void Print_MatchSet(MatchList &ML);

	//get the time
	string GetTime();

	//update the state of the clusters after each epoch
	void UpdateSearchSpace(std::vector<ASCS_Population> &population);

	//generate a file name for storing
	string Generate_File_Name(Config &cof, BooleanEnvironment &env);

	//save the trained result
	void Write_Result(std::vector<ASCS_Population> &populations, Config &cof, BooleanEnvironment &env, CompactionMechanism &CM);

    //convert the population to string
	string Population_Result(std::vector<ASCS_Population> &populations);

	//convert the trained result to string
	string Trained_Result(std::vector<ASCS_Population> &populations, CompactionMechanism &CM, Config &cof);


	//convert a vector to string
	string Convert_Vector(std::vector<int> &information, string begin);
};