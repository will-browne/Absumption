#include "Rule001_Oper.h";
#include "Rule_001.h";
#include <iostream>;
#include <stdlib.h>;  
#include<stdlib.h>;
#include<time.h>;
#include <string>;
#include"TrainingMechanism.h";
#include "Rule001_Oper.h";
#include"Rule_001.h"
#include "MatchList.h";
#include "BooleanEnvironment.h";
using namespace std;



//constructor of the training mechanism normally only need to receive a config document
TrainingMechanism::TrainingMechanism(Config &cof)
{
	TrainingMechanism::cof = cof;
}


MatchList TrainingMechanism::GetMatchList(std::vector<string> &state, std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &I_Action)
{
	MatchList ML;

	//population ID
	for (int p = 0; p < Populations.size(); ++p)
	{
		//Cluster ID
		for (int c = 0; c < Populations[p].Clusters.size(); ++c)
		{
			//Rule ID
			for (int r = 0; r < Populations[p].Clusters[c].Rules.size(); ++r)
			{
				if (R_O.IsConditionMatch(state, Populations[p].Clusters[c].Rules[r].condition))
				{
					//store the ID
					std::vector<int> ID{};
					ID.push_back(p);
					ID.push_back(c);
					ID.push_back(r);
					if (R_O.IsAbsumptionAndUpdate(Populations[p].Clusters[c].Rules[r], I_Action, Populations[p].Action, Populations[p].PN_state))
					{
						ML.Informed_L.push_back(ID);
					}
					else
					{
						ML.Absumption_L.push_back(ID);
					}


				}
			}

		}
	}

	return ML;
}



MatchList TrainingMechanism::Covering(std::vector<string> &state, std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &I_Action)
{
	
	MatchList ML = TrainingMechanism::GetMatchList(state, Populations, R_O, I_Action);
	if (ML.Absumption_L.size() + ML.Informed_L.size() == 0)
	{

		for (int p = 0; p < Populations.size(); ++p)
		{
			Rule_001 rule = R_O.CreateRule(Populations[p].Generalization_Level, state);
			Populations[p].Clusters[Populations[p].Generalization_Level].Rules.push_back(rule);
			//population's number rules add one
			Populations[p].num_Rules++;
			//cluster's number rules add one
			Populations[p].Clusters[Populations[p].Generalization_Level].T_Cov_num.back()++;
		}
	}
	return ML;
}


//a training iteration include one time covering, absumption, and informed mutation. new created rules will be introduced only if it is unsubsumable and not already exist
int TrainingMechanism::TrainingOnce(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, BooleanEnvironment &env)
{
	//randomly generate a sample of the target problem
	std::vector<int> state_i = env.Create_set_Condition();
	std::vector<string> state_s = env.Convert_state_char(state_i);
	int P_action = env.execute_Problem(state_i);
	//execute the covering
	MatchList ML = TrainingMechanism::Covering(state_s, Populations, R_O, P_action);

	//no rule is suitable, thus this iteration is finished
	if (ML.Absumption_L.size() + ML.Informed_L.size() == 0)
	{
		return 0;
	}

	//Implement the Absumption
	if (ML.Absumption_L.size() > 0)
	{
		TrainingMechanism::Absumption(Populations, ML.Absumption_L, state_s, R_O);
	}



	//implement the informed search
	// require not only exist rules in the informed list but also the first Population's number of rules is less than the P_size in the configure setting
	if ((ML.Informed_L.size() > 0) && (Populations[0].num_Rules<cof.P_Size))
	{
		TrainingMechanism::InformedMutation(Populations, ML.Informed_L, R_O);
	}



	//remove the rules in the absumption list
	if (ML.Absumption_L.size() > 0)
	{
		TrainingMechanism::AbsumptionRemover(Populations, ML.Absumption_L);
	}

	//free memory
	state_i.clear();
	state_i.shrink_to_fit();
	state_s.clear();
	state_s.shrink_to_fit();
	ML.Absumption_L.clear();
	ML.Absumption_L.shrink_to_fit();
	ML.Informed_L.clear();
	ML.Informed_L.shrink_to_fit();
	return 1;

}


void TrainingMechanism::Absumption(std::vector<ASCS_Population> &Populations, std::vector<std::vector<int>> &Ab_List, std::vector<string> &state, Rule001_Oper &R_O)
{
	//utilize the absumption list to create new rules
	for (int i = 0; i < Ab_List.size(); ++i)
	{
		//std::cout << Ab_List[i][0] << " " << Ab_List[i][1] << " " << Ab_List[i][2] << std::endl;
		//0: population id, 1:cluster id (generalization level), 2: rule id

		//if a rule does not possess a generalized attribute, it cannot be used to create new rule
		if (Ab_List[i][1] > 0)
		{
			//std::cout << Ab_List[i][1];
			Rule_001 Ab_rule = R_O.AbRule(state, Populations[Ab_List[i][0]].Clusters[Ab_List[i][1]].Rules[Ab_List[i][2]], Ab_List[i][1]);

			//new general level is equalivant to old generalization level minus one
			int new_level = Ab_List[i][1] - 1;



			//if new created does not exist in the population and cannot be subsumed by any other rule
			if (!(TrainingMechanism::RuleExist(Populations[Ab_List[i][0]], Ab_rule.condition, new_level, R_O))
				&& !(TrainingMechanism::RuleSubsumed(Populations[Ab_List[i][0]], Ab_rule.condition, new_level, R_O)))
			{
				Populations[Ab_List[i][0]].Clusters[new_level].Rules.push_back(Ab_rule);

				//population's number rules add one
				Populations[Ab_List[i][0]].num_Rules++;
				//cluster's number rules add one
				Populations[Ab_List[i][0]].Clusters[new_level].T_Aubsumed_num.back()++;
			}
			//free memory
			else
			{
				Ab_rule.Attributelist.clear();
				Ab_rule.Attributelist.shrink_to_fit();
				Ab_rule.condition.clear();
				Ab_rule.condition.shrink_to_fit();
			}
		}


	}
}


bool TrainingMechanism::RuleExist(ASCS_Population &Population, std::vector<string> &condition, int &GeneralLevel, Rule001_Oper &R_O)
{
	//no rules in this cluster thus this rule must not exist
	if (Population.Clusters[GeneralLevel].Rules.size() == 0)
	{
		return false;
	}


	for (int i = 0; i < Population.Clusters[GeneralLevel].Rules.size(); ++i)
	{
		//when rule exist return true
		if (R_O.SameCondition(Population.Clusters[GeneralLevel].Rules[i].condition, condition))
		{
			return true;
		}
	}

	//no rule possesses the same condition
	return false;
}


bool TrainingMechanism::RuleSubsumed(ASCS_Population &Population, std::vector<string> &condition, int &GeneralLevel, Rule001_Oper &R_O)
{
	//when rule can be subsumed true
	for (int i = GeneralLevel + 1; i < Population.Clusters.size(); ++i)
	{

		for (int j = 0; j < Population.Clusters[i].Rules.size(); ++j)
		{

			if (Population.Clusters[i].Rules[j].Sub_state == true)
			{

				if (R_O.SubsumeCondition(Population.Clusters[i].Rules[j].condition, condition))
				{
					return true;
				}
			}
		}
	}

	//rule cannot be subsumed
	return false;
}


void TrainingMechanism::AbsumptionRemover(std::vector<ASCS_Population> &Populations, std::vector<std::vector<int>> &Ab_List)
{
	//initial population id and cluster id
	int p = Ab_List[0][0];
	int c = Ab_List[0][1];
	int count = 0;

	for (int i = 0; i < Ab_List.size(); ++i)
	{
		//remove the marked rule
		/*if (count > 1)
		{
			cout << p << " " << c << " " << endl;
			cout << Ab_List[i][0] << " " << Ab_List[i][1] << " " << Ab_List[i][2] << endl;
			cout << count << endl;
			cout << Ab_List[i][2] - count << endl;

			cout << "==========================================" << endl;
		}*/
		//Must brackets (Ab_List[i][2]-count), otherwise, raise up errors
		Populations[p].Clusters[c].Rules.erase(Populations[p].Clusters[c].Rules.begin() + (Ab_List[i][2] - count));

		//population's number rules minus one
		Populations[p].num_Rules--;


		//before the last one
		if (i < Ab_List.size() - 1)
		{
			//set the count
			if (p == Ab_List[i + 1][0] && c == Ab_List[i + 1][1])
			{
				count++;
			}
			else
			{
				count = 0;
				p = Ab_List[i + 1][0];
				c = Ab_List[i + 1][1];
			}
		}
	}
}


void TrainingMechanism::InformedMutation(std::vector<ASCS_Population> &Populations, std::vector<std::vector<int>> &IF_List, Rule001_Oper &R_O)
{
	//initial population id and cluster id
	int p = IF_List[0][0];
	int c = IF_List[0][1];
	int count = 1;
	int mark = 0;

	//Utilize the informed list to create new rules
	//in each general level select one rule to create a new rule 
	for (int i = 0; i < IF_List.size() - 1; ++i)
	{
		//0: population id, 1:cluster id (generalization level), 2: rule id



		if (p == IF_List[i + 1][0] && c == IF_List[i + 1][1])
		{
			//count the number of rules in this cluster
			count++;
		}


		//p change c change or reach to the last matched rule
		if ((p != IF_List[i + 1][0]) || (c != IF_List[i + 1][1]) || ((i + 1) == (IF_List.size() - 1)))
		{

			//The highest general level can not be undergo the informed mutation
			if (c < R_O.PL)
			{
				int new_level = c + 1;
				//the new cluster is allowed to be explored
				if (Populations[p].Clusters[new_level].Active == true)
				{
					//randomly select an rule in the list
					int random_location;
					srand(TrainingMechanism::seed);
					TrainingMechanism::seed++;
					random_location = rand() % count;


					//cout << Populations[p].Clusters[c].Rules.size() << endl;
					//cout << (random_location + mark) << endl;
					//cout << IF_List.size() << endl;
					//cout << "================================" << endl;
					//generalization level is equlivant to the rule adhere cluster
					Rule_001 IF_rule = R_O.InformRule(Populations[p].Clusters[c].Rules[IF_List[(random_location + mark)][2]], c);



					//check whether this rule can be inserted into the population
					bool InsertState;

					if (new_level == R_O.PL)
					{
						InsertState = !(TrainingMechanism::RuleExist(Populations[p], IF_rule.condition, new_level, R_O));
					}
					else
					{
						InsertState = (!(TrainingMechanism::RuleExist(Populations[p], IF_rule.condition, new_level, R_O))
							&& !(TrainingMechanism::RuleSubsumed(Populations[p], IF_rule.condition, new_level, R_O)));
					}

					//insert the rule and update the recored parameters
					if (InsertState)
					{
						Populations[p].Clusters[new_level].Rules.push_back(IF_rule);

						//population's number rules add one
						Populations[p].num_Rules++;
						//cluster's evolved number rules add one
						Populations[p].Clusters[new_level].T_Evolved_num.back()++;

					}
					//free memory
					else
					{
						IF_rule.Attributelist.clear();
						IF_rule.Attributelist.shrink_to_fit();
						IF_rule.condition.clear();
						IF_rule.condition.shrink_to_fit();
					}
				}
			}


			//defalut the population ID cluster ID and the initial location
			count = 1;
			//mark the begin location of the new cluster
			mark = i + 1;
			p = IF_List[i + 1][0];
			c = IF_List[i + 1][1];

		}

	}
}


void TrainingMechanism::run(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, BooleanEnvironment &env)
{
	for (int i = 0; i < cof.T_number; ++i)
	{
		TrainingMechanism::TrainingOnce(Populations, R_O, env);
	}
}