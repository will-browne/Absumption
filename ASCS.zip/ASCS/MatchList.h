#pragma once
using namespace std;
#include <vector>;
#include "Rule_001.h";
#include "PopulationPool.h";
#include "Rule001_Oper.h";


struct MatchList
{
public:
	//the IDs of the rules for absumption
	std::vector<std::vector<int>> Absumption_L{};

	//the IDs of the rules for informed search
	std::vector<std::vector<int>> Informed_L{};
};