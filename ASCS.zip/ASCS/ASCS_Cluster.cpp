#include "ASCS_Cluster.h";


ASCS_Cluster::ASCS_Cluster()
{
	ASCS_Cluster::C_Aubsumed_num.push_back(0);

	ASCS_Cluster::C_Subsumed_num.push_back(0);

	ASCS_Cluster::C_Error_num.push_back(0);



	ASCS_Cluster::T_Aubsumed_num.push_back(0);

	ASCS_Cluster::T_Subsumed_num.push_back(0);

	ASCS_Cluster::T_Evolved_num.push_back(0);

	ASCS_Cluster::T_Cov_num.push_back(0);

	
};