#pragma once;
using namespace std;
#include <vector>;
#include "ASCS_Cluster.h";


class ASCS_Population
{
public:

	//Initial the Population require this population's advocated action and PNstate
	ASCS_Population(bool PN, int action);

	//the state of the population identify whether this population support the negative rules or positive rules
	//// 0: negative 1:positive
	bool PN_state;

	//this population advocated action
	int Action;


	//the number of rules in this population
	int num_Rules;


	//the Clusters in this population
	std::vector<ASCS_Cluster> Clusters{};

	//highest generanlization
	int Generalization_Level;
};
